<?php

	header ("Content-Type: text/javascript");

	echo "var LANG_PASTEHERE = '". plugin_lang_get( "pastehere" ) ."'; ";